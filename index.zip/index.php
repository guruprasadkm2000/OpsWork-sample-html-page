<!DOCTYPE html>
<html>
<body bgcolor="yellow">

<h1 align="center">My first PHP page</h1>

<?php
echo "Hello World!";
?>

</body>
</html>